import { useEffect, useState } from "react";
import * as api from "../api";
import type { ActivationStatus, Application, DocumentSubmission } from "../api";
import { Alert, Badge, BentoCard, EmptyState, PageHeader, Spinner, formatDomainLabel } from "../components/ui";
import PlacementHistory from "../components/PlacementHistory";
import { hoursFromHistory, totalHours, type HoursEntry } from "../progress";
import { HOURS_REVIEW_LABELS } from "../segments";

export default function Documents() {
  const [apps, setApps] = useState<Application[] | null>(null);
  const [statuses, setStatuses] = useState<Record<number, ActivationStatus>>({});
  const [submissions, setSubmissions] = useState<Record<string, DocumentSubmission[]>>({});
  const [hours, setHours] = useState<Record<number, HoursEntry[]>>({});
  const [hoursDraft, setHoursDraft] = useState<Record<number, string>>({});
  const [workDateDraft, setWorkDateDraft] = useState<Record<number, string>>({});
  const [descriptionDraft, setDescriptionDraft] = useState<Record<number, string>>({});
  const [files, setFiles] = useState<Record<number, File>>({});
  const [busy, setBusy] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  async function reload() {
    setError(null);
    try {
      const list = await api.listApplications();
      const placements = list.filter((a) => a.placement_id &&
        (a.placement_state === "DOCUMENTATION_PENDING" || a.placement_state === "ACTIVE"));
      const statusPairs = await Promise.all(placements.map(async (a) => {
        const pid = a.placement_id!;
        return [pid, await api.activationStatus(pid)] as const;
      }));
      const statusMap = Object.fromEntries(statusPairs);
      const submissionPairs = await Promise.all(placements.flatMap((a) => {
        const pid = a.placement_id!;
        return statusMap[pid].items.map(async (item) => [
          `${pid}:${item.id}`,
          await api.listDocumentSubmissions(pid, item.id),
        ] as const);
      }));
      const hoursPairs = await Promise.all(placements
        .filter((a) => a.placement_state === "ACTIVE")
        .map(async (a) => [a.placement_id!, hoursFromHistory(await api.listPlacementHours(a.placement_id!))] as const));
      setApps(list);
      setStatuses(statusMap);
      setSubmissions(Object.fromEntries(submissionPairs));
      setHours(Object.fromEntries(hoursPairs));
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  }

  useEffect(() => { void reload(); }, []);

  async function submit(pid: number, itemId: number) {
    const file = files[itemId];
    if (!file) return;
    setBusy(itemId);
    setError(null);
    setMessage(null);
    try {
      const result = await api.submitDocument(pid, itemId, file);
      setFiles((current) => {
        const next = { ...current };
        delete next[itemId];
        return next;
      });
      setMessage(`Documento enviado como versión ${result.revision}.`);
      await reload();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(null);
    }
  }

  async function download(pid: number, itemId: number, submission: DocumentSubmission) {
    setError(null);
    try {
      await api.downloadDocument(pid, itemId, submission);
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    }
  }

  async function recordHours(pid: number, event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const value = Number(hoursDraft[pid]);
    if (!Number.isFinite(value) || value <= 0) {
      setError("Ingresa una cantidad de horas mayor que cero.");
      return;
    }
    setBusy(pid);
    setError(null);
    setMessage(null);
    try {
      await api.recordPlacementHours(pid, value, {
        work_date: workDateDraft[pid] || undefined,
        description: descriptionDraft[pid] || undefined,
      });
      setHoursDraft((current) => ({ ...current, [pid]: "" }));
      setWorkDateDraft((current) => ({ ...current, [pid]: "" }));
      setDescriptionDraft((current) => ({ ...current, [pid]: "" }));
      setMessage("Las horas quedaron registradas en el segmento activo y quedan pendientes de revisión.");
      await reload();
    } catch (err) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(null);
    }
  }

  const placements = (apps ?? []).filter((a) => a.placement_id &&
    (a.placement_state === "DOCUMENTATION_PENDING" || a.placement_state === "ACTIVE"));

  return (
    <div className="page-stack">
      <PageHeader eyebrow="MI PRÁCTICA" title="Mis documentos" description="Consulta los requisitos, entrega archivos y revisa las decisiones del equipo académico." />
      <Alert kind="info">Carga únicamente archivos sintéticos para esta demostración. Se aceptan PDF, PNG, JPG y DOCX de hasta 10 MB.</Alert>
      {error && <Alert kind="error">{error}</Alert>}
      {message && <Alert kind="success">{message}</Alert>}
      {apps === null && !error && <div className="empty"><Spinner /> Cargando…</div>}
      {apps !== null && placements.length === 0 && (
        <EmptyState message="No tienes prácticas con requisitos documentales pendientes o en seguimiento." />
      )}
      {placements.map((a) => {
        const pid = a.placement_id!;
        const status = statuses[pid];
        return (
          <BentoCard variant="content" className="document-placement" key={a.id}>
            <div className="row">
              <div className="spacer">
                <h3>{a.title} · práctica</h3>
                <p className="muted">{a.placement_state === "ACTIVE" ? "Práctica activa" : "Documentación para activación"}</p>
              </div>
              <Badge>{a.placement_state}</Badge>
            </div>
            {status && a.placement_state === "DOCUMENTATION_PENDING" && (
              <p className="muted">
                {status.ready_to_activate
                  ? "Los requisitos están aprobados; el coordinador puede activar la práctica."
                  : `Pendiente para activar: ${status.unmet.map(formatDomainLabel).join(", ") || "—"}`}
              </p>
            )}
            {status?.activation_noncompliant && (
              <Alert kind="info">La práctica sigue activa. Corrige los requisitos rechazados para completar el ciclo.</Alert>
            )}
            {a.placement_state === "ACTIVE" && (
              <section className="card work-log-card" aria-label={`Seguimiento de horas de ${a.title}`}>
                <div className="section-heading">
                  <div><span className="eyebrow">SEGUIMIENTO</span><h2>Horas de práctica</h2>
                    <p>Las horas se registran en el segmento activo. Son horas reportadas: solo cuentan para el cierre cuando el rol revisor configurado las acepta.</p>
                  </div>
                  <strong className="metric-value">{totalHours(hours[pid] ?? [])} h</strong>
                </div>
                <form className="row" onSubmit={(event) => void recordHours(pid, event)}>
                  <div className="field"><label htmlFor={`hours-${pid}`}>Horas realizadas</label>
                    <input id={`hours-${pid}`} type="number" min="0.1" step="0.1" required value={hoursDraft[pid] ?? ""}
                      onChange={(event) => setHoursDraft((current) => ({ ...current, [pid]: event.target.value }))} />
                  </div>
                  <div className="field"><label htmlFor={`work-date-${pid}`}>Fecha de la jornada (opcional)</label>
                    <input id={`work-date-${pid}`} type="date" value={workDateDraft[pid] ?? ""}
                      onChange={(event) => setWorkDateDraft((current) => ({ ...current, [pid]: event.target.value }))} />
                  </div>
                  <div className="field"><label htmlFor={`hours-description-${pid}`}>Descripción (opcional)</label>
                    <input id={`hours-description-${pid}`} maxLength={1000} value={descriptionDraft[pid] ?? ""}
                      onChange={(event) => setDescriptionDraft((current) => ({ ...current, [pid]: event.target.value }))} />
                  </div>
                  <button className="btn" type="submit" disabled={busy === pid || !hoursDraft[pid]}>
                    {busy === pid ? <Spinner /> : "Registrar horas"}
                  </button>
                </form>
                {(hours[pid] ?? []).length > 0 ? (
                  <ul className="work-log-list">
                    {(hours[pid] ?? []).map((entry) => (
                      <li key={entry.id}><span>{new Date(entry.occurredAt).toLocaleString("es-CO")}{entry.segmentNo ? ` · segmento ${entry.segmentNo}` : ""}{entry.reviewStatus ? ` · ${HOURS_REVIEW_LABELS[entry.reviewStatus] ?? entry.reviewStatus}` : ""}</span><strong>{entry.hours} h</strong></li>
                    ))}
                  </ul>
                ) : <p className="muted">Todavía no hay horas registradas.</p>}
              </section>
            )}
            <PlacementHistory placementId={pid} />
            {status && status.items.length > 0 && (
              <div className="table-scroll" tabIndex={0} aria-label={`Requisitos documentales de ${a.title}`}><table>
                <thead><tr><th>Requisito</th><th>Estado</th><th>Entrega actual</th><th>Revisión</th><th>Acción</th></tr></thead>
                <tbody>
                  {status.items.map((item) => {
                    const history = submissions[`${pid}:${item.id}`] ?? [];
                    const latest = history[0];
                    return (
                      <tr key={item.id}>
                        <td>{formatDomainLabel(item.kind)}{item.mandatory ? " · obligatorio" : " · opcional"}</td>
                        <td><Badge>{item.status}</Badge></td>
                        <td>
                          {latest ? (
                            <div>
                              <span>{latest.original_filename} · v{latest.revision}</span>
                              <div><button className="btn link" onClick={() => void download(pid, item.id, latest)}>Descargar</button></div>
                            </div>
                          ) : <span className="muted">Sin archivo</span>}
                        </td>
                        <td>
                          {latest?.decision ? <><Badge>{latest.decision}</Badge><div>{latest.reason}</div></>
                            : <span className="muted">{item.status === "SUBMITTED" ? "En revisión" : "—"}</span>}
                        </td>
                        <td>
                          {item.kind.startsWith("DOC_") && (item.status === "REQUIRED" || item.status === "REJECTED") && (
                            <div className="field">
                              <input
                                aria-label={`Archivo para ${formatDomainLabel(item.kind)}`}
                                type="file"
                                accept=".pdf,.png,.jpg,.jpeg,.docx,application/pdf,image/png,image/jpeg,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
                                onChange={(event) => {
                                  const selected = event.currentTarget.files?.[0];
                                  if (selected) setFiles((current) => ({ ...current, [item.id]: selected }));
                                }}
                              />
                              <button className="btn" disabled={!files[item.id] || busy === item.id}
                                onClick={() => void submit(pid, item.id)}>
                                {busy === item.id ? <Spinner /> : item.status === "REJECTED" ? "Reenviar" : "Enviar"}
                              </button>
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table></div>
            )}
          </BentoCard>
        );
      })}
    </div>
  );
}
